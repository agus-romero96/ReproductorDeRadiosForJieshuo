require "import"
import "android.widget.*"
import "android.view.*"
import "com.androlua.LuaDialog"
import "com.androlua.Http"
import "android.content.Context"

local M = {}
local utils = require("utils")
local radio_manager = require("radio_manager")
local json = require("cjson")

-- Caché de resultados para no perderlos al girar pantalla o volver
local currentResults = {}

-- Función segura para decodificar la API
local function safeDecode(jsonString)
    if not jsonString or jsonString == "" then return {} end
    local status, res = pcall(json.decode, jsonString)
    if status then return res else return {} end
end

function M.MostrarApi(filtro, ui_principal)
    local dlg = LuaDialog(service)
    
    -- Layout Declarativo (Más seguro para loadlayout)
    local layout = {
        LinearLayout,
        orientation = LinearLayout.VERTICAL,
        padding = "16dp",
        -- Título
        { TextView, text=utils.getTranslation("titulo_api"), textSize="20sp", gravity="center", paddingBottom="10dp" },
        
        -- Campo de Búsqueda
        { EditText, id="etBusqueda", hint=utils.getTranslation("search_prompt"), layout_width="fill" },
        
        -- Botón Buscar
        { Button, id="btnBuscar", text=utils.getTranslation("buscar"), layout_width="fill" },
        
        -- Estado
        { TextView, id="tvEstado", text="", gravity=Gravity.CENTER, padding="5dp" },
        
        -- Lista de Resultados (Envuelta en Layout con peso)
        {
            LinearLayout, 
            layout_width="fill", 
            layout_height="0", 
            layout_weight=1,
            { ListView, id="lvResultados", layout_width="fill", layout_height="fill" }
        },
        
        -- Botones Inferiores
        {
            LinearLayout, orientation="horizontal", layout_marginTop="8dp", layout_width="fill",
            { Button, text=utils.getTranslation("showPlayer"), layout_weight=1, onClick=function() radio_manager.MostrarReproductor() end },
            { Button, text=utils.getTranslation("volver"), layout_weight=1, onClick=function() dlg.dismiss(); if ui_principal then ui_principal.mainMenu() end end }
        }
    }

    dlg.setView(loadlayout(layout))
    
    -- Lógica de Búsqueda
    btnBuscar.setOnClickListener(function()
        local query = etBusqueda.getText().toString()
        if query == "" then return end
        
        -- Ocultar teclado
        local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
        imm.hideSoftInputFromWindow(etBusqueda.getWindowToken(), 0)
        
        tvEstado.setText(utils.getTranslation("searching"))
        service.asyncSpeak(utils.getTranslation("searching"))
        
        -- Búsqueda asíncrona a Radio-Browser
        local url = "https://de1.api.radio-browser.info/json/stations/search?limit=50&name=" .. query:gsub(" ", "%%20")
        
        Http.get(url, function(code, body)
            -- Volver al hilo principal
            local handler = luajava.bindClass("android.os.Handler")(luajava.bindClass("android.os.Looper").getMainLooper())
            handler.post(function()
                if code == 200 then
                    local radios = safeDecode(body)
                    currentResults = radios 
                    
                    if #radios > 0 then
                        local nombres = {}
                        for _, r in ipairs(radios) do
                            local label = (r.name or "Radio") .. "\n" .. (r.country or "") .. " (" .. (r.bitrate or "0") .. "k)"
                            table.insert(nombres, label)
                        end
                        
                        local adapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, String(nombres))
                        lvResultados.setAdapter(adapter)
                        
                        local msg = string.format(utils.getTranslation("results_found"), #radios)
                        tvEstado.setText(msg)
                        service.asyncSpeak(msg)
                    else
                        tvEstado.setText(utils.getTranslation("no_results"))
                        service.asyncSpeak(utils.getTranslation("no_results"))
                        lvResultados.setAdapter(nil)
                    end
                else
                    tvEstado.setText("Error API: " .. code)
                    service.asyncSpeak(utils.getTranslation("error_stream"))
                end
            end)
        end)
    end)
    
    -- Click en resultado
    lvResultados.setOnItemClickListener(function(parent, view, position, id)
        local radio = currentResults[position + 1]
        if not radio then return end
        
        local nombre = radio.name or utils.getTranslation("sin_nombre")
        local url = radio.url_resolved or radio.url
        local pais = radio.country or utils.getTranslation("pais_desconocido")
        
        -- Menú contextual
        local menu = LuaDialog(service)
        menu.setTitle(nombre)
        local opciones = {
            utils.getTranslation("play"),
            utils.getTranslation("guarda_favorito"),
            utils.getTranslation("copiar"),
            utils.getTranslation("cancelar")
        }
        
        local menuList = ListView(service)
        menuList.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, String(opciones)))
        
        menuList.setOnItemClickListener(function(p, v, pos, i)
            menu.dismiss()
            if pos == 0 then -- Play
                radio_manager.playRadio(nombre, url)
            elseif pos == 1 then -- Guardar
                radio_manager.agregarRadio(nombre, url, pais)
            elseif pos == 2 then -- Copiar
                service.copy(url)
                service.asyncSpeak(utils.getTranslation("ready"))
            end
        end)
        
        menu.setView(menuList)
        menu.show()
    end)

    dlg.show()
end

return M