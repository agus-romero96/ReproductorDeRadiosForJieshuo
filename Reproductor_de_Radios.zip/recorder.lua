require "import"
import "java.net.URL"
import "java.io.FileOutputStream"
import "java.io.File"
import "android.os.Environment"
import "java.text.SimpleDateFormat"
import "java.util.Date"

local M = {}
local isRecording = false
local utils = require("utils")

-- Ruta de guardado
local function getOutputFolder()
    local path = Environment.getExternalStorageDirectory().toString() .. "/Music/RadioRecordings"
    local folder = File(path)
    if not folder.exists() then folder.mkdirs() end
    return path
end

-- Generar nombre de archivo único
local function getFileName(radioName)
    local date = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
    -- Limpiar nombre de caracteres inválidos
    local cleanName = radioName:gsub("[^%w%s]", ""):gsub("%s+", "_")
    return cleanName .. "_" .. date .. ".mp3"
end

function M.isRecording()
    return isRecording
end

function M.start(url, radioName)
    if isRecording then return end
    isRecording = true
    
    service.asyncSpeak(utils.getTranslation("record_start"))
    
    -- Ejecutamos en un hilo secundario (task) para no congelar la app
    task(function(url, radioName, folderPath, fileName)
        require "import"
        import "java.net.URL"
        import "java.io.FileOutputStream"
        import "java.io.File"
        
        local fullPath = folderPath .. "/" .. fileName
        local success = false
        
        pcall(function()
            local u = URL(url)
            local conn = u.openConnection()
            conn.setConnectTimeout(10000)
            conn.setReadTimeout(10000)
            
            -- Headers para evitar bloqueos (Disfraz de VLC)
            conn.setRequestProperty("User-Agent", "VLC/3.0.16 LibVLC/3.0.16")
            
            local inputStream = conn.getInputStream()
            local outputStream = FileOutputStream(File(fullPath))
            
            local buffer = byte[4096] -- Buffer de 4KB
            local len = inputStream.read(buffer)
            
            -- Bucle de grabación
            while len ~= -1 and isRecording do
                outputStream.write(buffer, 0, len)
                len = inputStream.read(buffer)
            end
            
            outputStream.close()
            inputStream.close()
            success = true
        end)
        
        return success, fullPath
    end, url, radioName, getOutputFolder(), getFileName(radioName), function(ok, path)
        -- Callback al terminar
        isRecording = false -- Asegurar estado
        if ok then
            service.asyncSpeak(utils.getTranslation("record_saved"))
        else
            service.asyncSpeak(utils.getTranslation("record_error"))
        end
    end)
end

function M.stop()
    if isRecording then
        isRecording = false -- Esto rompe el bucle while dentro del task
        service.asyncSpeak(utils.getTranslation("record_stop"))
    end
end

return M