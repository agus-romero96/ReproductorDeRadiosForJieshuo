require "import"
import "android.widget.*"
import "android.view.*"
import "com.androlua.LuaDialog"
import "android.content.Context"

local M = {}
local radio_manager = require("radio_manager")
local utils = require("utils")

local dlg -- Referencia al diálogo actual para poder cerrarlo

-- Helper corto para traducciones
local function T(key) return utils.getTranslation(key) end

-- 3. Formulario Final: Detalles (Nombre/País)
local function showAddDetailsForm(url, parent_ui)
    local layout = {
        LinearLayout,
        orientation = LinearLayout.VERTICAL,
        padding = "16dp",
        {
            EditText,
            id = "nombreRadio",
            hint = T("nombre"), -- "Nombre de la Radio"
            layout_width = "match_parent",
            layout_height = "wrap_content",
        },
        {
            EditText,
            id = "paisRadio",
            hint = T("pais_radio"), -- "País de la Radio"
            layout_width = "match_parent",
            layout_height = "wrap_content",
        },
        {
            EditText,
            text = url,
            hint = T("url"),
            layout_width = "match_parent",
            layout_height = "wrap_content",
            enabled = false, -- Solo lectura
            textColor = "#AAAAAA"
        },
        {
            LinearLayout,
            orientation = LinearLayout.HORIZONTAL,
            layout_marginTop = "16dp",
            {
                Button,
                text = T("cancelar"),
                onClick = function()
                    dlg.dismiss()
                    if parent_ui then parent_ui.mainMenu() end
                end,
                layout_weight = 1,
            },
            {
                Button,
                text = T("agregar"), -- "Guardar"
                onClick = function()
                    local nombre = nombreRadio.getText().toString()
                    local pais = paisRadio.getText().toString()

                    if nombre == "" or pais == "" then
                        service.asyncSpeak(T("error_datos"))
                        return
                    end

                    -- Guardar en Storage v2
                    radio_manager.agregarRadio(nombre, url, pais)
                    service.asyncSpeak(T("guardada_ok"))
                    
                    dlg.dismiss()
                    if parent_ui then parent_ui.mainMenu() end
                end,
                layout_weight = 1,
            },
        },
    }

    dlg = LuaDialog(service)
    dlg.setTitle(T("addRadio"))
    dlg.setView(loadlayout(layout))
    dlg.show()
end

-- 2. Formulario Intermedio: Opciones tras verificar
local function showOptionsForm(url, parent_ui)
    local layout = {
        LinearLayout,
        orientation = LinearLayout.VERTICAL,
        padding = "16dp",
        {
            TextView,
            text = T("url_valida") .. "\n" .. T("opciones_url"),
            textSize = "18sp",
            gravity = "center",
            paddingBottom = "16dp",
        },
        {
            Button,
            text = T("agregar"), -- "Agregar a BD"
            onClick = function()
                dlg.dismiss()
                showAddDetailsForm(url, parent_ui)
            end,
            layout_width = "match_parent",
        },
        {
            Button,
            text = T("play"), -- "Reproducir"
            onClick = function()
                dlg.dismiss()
                radio_manager.playRadio("Stream", url)
                if parent_ui then parent_ui.mainMenu() end
            end,
            layout_width = "match_parent",
        },
        {
            Button,
            text = T("cancelar"),
            onClick = function()
                dlg.dismiss()
                if parent_ui then parent_ui.mainMenu() end
            end,
            layout_width = "match_parent",
        },
    }

    dlg = LuaDialog(service)
    dlg.setView(loadlayout(layout))
    dlg.show()
end

-- 1. Formulario Inicial: Ingreso de URL
function M.showAddRadioForm(parent_ui)
    local layout = {
        LinearLayout,
        orientation = LinearLayout.VERTICAL,
        padding = "16dp",
        {
            TextView,
            text = T("addRadio"),
            textSize = "20sp",
            gravity = "center",
            paddingBottom = "16dp",
        },
        {
            EditText,
            id = "urlRadio",
            hint = "http://...",
            inputType = "textUri", -- Teclado optimizado para URL
            layout_width = "match_parent",
            layout_height = "wrap_content",
        },
        {
            LinearLayout,
            orientation = LinearLayout.HORIZONTAL,
            layout_marginTop = "16dp",
            {
                Button,
                text = T("cancelar"),
                onClick = function()
                    dlg.dismiss()
                    if parent_ui then parent_ui.mainMenu() end
                end,
                layout_weight = 1,
            },
            {
                Button,
                text = T("buscar"), -- Usamos "Buscar" o "Verificar"
                onClick = function()
                    local url = urlRadio.getText().toString()
                    if url == "" then
                        service.asyncSpeak(T("url_invalida"))
                        return
                    end
                    
                    service.asyncSpeak(T("verificando"))
                    
                    -- Usamos el verificador del manager
                    radio_manager.verificarURL(url, function(isValid)
                        if isValid then
                            dlg.dismiss()
                            showOptionsForm(url, parent_ui)
                        else
                            service.asyncSpeak(T("url_invalida"))
                        end
                    end)
                end,
                layout_weight = 1,
            },
        },
    }

    dlg = LuaDialog(service)
    dlg.setView(loadlayout(layout))
    dlg.show()
end

return M