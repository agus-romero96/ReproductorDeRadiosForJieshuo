require "import"
import "android.content.Context"
import "android.os.Vibrator"
import "java.io.File"

-- 1. VERSIÓN ACTUAL
local PLUGIN_VERSION = 2.1 

-- ==================================================
-- ⚠️ ZONA GLOBAL (Para compatibilidad inmediata)
-- ==================================================
-- Definimos esto GLOBALMENTE para que ui_principal.lua no falle
context = activity or service
vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)
-- ==================================================

-- 2. DETECCIÓN DINÁMICA DE RUTA (Estilo Gemini)
local function getBasePath()
    local path = debug.getinfo(1, "S").source:sub(2)
    local file = File(path)
    return file.getParent()
end

local basePath = getBasePath()

-- 3. CONFIGURAR LUA PARA ENCONTRAR TUS MÓDULOS
-- Esto hace que 'require' funcione en todos los archivos sin que tengas que tocarlos
package.path = basePath .. "/?.lua;" .. package.path

-- 4. CARGA DE MÓDULOS
local utils = require("utils")
local updater = require("updater")
local radio_manager = require("radio_manager")
local ui_principal = require("ui_principal")

-- 5. INICIALIZAR ACTUALIZADOR
-- Puse esto dentro de un pcall por si acaso falla algo en el updater
pcall(function()
    updater.init(service, context, basePath)
    updater.check(PLUGIN_VERSION)
end)

-- 6. LÓGICA DE INICIO
if _G.radioPlaying then
    radio_manager.MostrarReproductor()
else
    ui_principal.mainMenu()
end

return true