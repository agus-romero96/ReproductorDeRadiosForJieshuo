require "import"
import "android.content.Context"
import "java.io.File"

-- 1. CONFIGURACIÓN DE VERSIÓN
-- Incrementa este número cuando subas cambios a GitHub
local PLUGIN_VERSION = 2.0 

local context = activity or service

-- 2. DETECCIÓN INTELIGENTE DE RUTA
-- Detectamos dónde está instalado el plugin exactamente
local function getBasePath()
    local possiblePaths = {
        "/storage/emulated/0/解说/Plugins/Reproductor de Radios",
        "/storage/emulated/0/解说/Complementos/Reproductor de Radios"
    }
    for _, path in ipairs(possiblePaths) do
        if File(path).exists() then return path end
    end
    return nil
end

local basePath = getBasePath()

if not basePath then
    service.asyncSpeak("Error: No encuentro la carpeta del Reproductor de Radios.")
    return true
end

-- Añadir al path de Lua para que los require funcionen
package.path = basePath .. "/?.lua;" .. package.path

-- 3. CARGA DE MÓDULOS
local utils = require("utils")
local updater = require("updater")
local radio_manager = require("radio_manager")
local ui_principal = require("ui_principal")

-- 4. INICIALIZACIÓN DEL ACTUALIZADOR
-- Se ejecuta en segundo plano, no bloquea el inicio
updater.init(service, context, basePath)
updater.check(PLUGIN_VERSION)

-- 5. LÓGICA DE INICIO (UI vs Reproductor)
-- Si ya está sonando, mostramos el reproductor flotante. Si no, el menú principal.
if _G.radioPlaying then
    radio_manager.MostrarReproductor()
else
    ui_principal.mainMenu()
end

return true