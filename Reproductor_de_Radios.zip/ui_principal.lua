local M = {}
local utils = require("utils")

function M.showLanguageDialog()
local dialog = LuaDialog(service)
dialog.setTitle(utils.getTranslation("tit_idioma"))
local layout = {
LinearLayout,
orientation = LinearLayout.VERTICAL,
{
Button,
text = "Español",
onClick = function(view)
utils.setLanguage("es")
service.asyncSpeak("Idioma cambiado a Español")
vibrator.vibrate(100)
dialog.dismiss()
M.mainMenu() -- Refresca el menú principal con el nuevo idioma
end
},
{
Button,
text = "English",
onClick = function(view)
utils.setLanguage("en")
service.asyncSpeak("Language changed to English")
vibrator.vibrate(100)
dialog.dismiss()
M.mainMenu() -- Refresca el menú principal con el nuevo idioma
end
},
{
Button,
text = "Cancelar",
onClick = function(view)
vibrator.vibrate(100)
dialog.dismiss()
end
},
}
local contentView = loadlayout(layout)
dialog.setView(contentView)
dialog.setCancelable(true)
dialog.show()
end

function M.mainMenu()
if not utils.VerifiConex() then
service.asyncSpeak(utils.getTranslation("noConnection"))
vibrator.vibrate(200)
return
end
layout = {
LinearLayout,
orientation = LinearLayout.VERTICAL,
{
TextView,
text = utils.getTranslation("welcome"),
textSize = "20sp",
gravity = "center",
padding = "16dp",
},
{
GridView,
id = "grid",
numColumns = 3,
layout_width = "fill",
layout_height = "0dp",
layout_weight = 1,
gravity = "center"
},
{
LinearLayout,
orientation = LinearLayout.HORIZONTAL,
layout_width = "fill",
layout_height = "wrap_content",
{
Button,
text = utils.getTranslation("showPlayer"),
onClick = function()
dlg.dismiss()
require("radio_manager").MostrarReproductor()
end,
layout_width = "0dp",
layout_height = "wrap_content",
layout_weight = 1,
layout_gravity = "start"
},
{
Button,
text = utils.getTranslation("exit"),
onClick = function()
vibrator.vibrate(100)
dlg.dismiss()
end,
layout_width = "0dp",
layout_height = "wrap_content",
layout_weight = 1,
layout_gravity = "end"
},
{
Button,
text = utils.getTranslation("idioma"),
onClick = function()
dlg.dismiss()
M.showLanguageDialog()
end,
layout_width = "0dp",
layout_height = "wrap_content",
layout_weight = 1,
layout_gravity = "center"
},
}
}

dlg = LuaDialog(service)
dlg.View = loadlayout(layout)

opciones = {
utils.getTranslation("searchRadio"), 
utils.getTranslation("savedRadios"), 
utils.getTranslation("addRadio")
}

grid.adapter = SingleLineAdapter(service, String(opciones))
dlg.show()
vibrator.vibrate(100)
grid.onItemClick = function(l, v)
task(100, function()
dlg.dismiss()
vibrator.vibrate(100)
if v.text == utils.getTranslation("searchRadio") then
require("ui_lista").MostrarApi("Todas", M)
elseif v.text == utils.getTranslation("savedRadios") then
require("guardadas").MostrarGuardadas("Favoritas", M)
elseif v.text == utils.getTranslation("addRadio") then
require("ui_agregar").showAddRadioForm(M)
end
end)
end
end

return M