require "import"
import "android.widget.*"
import "android.view.*"
import "com.androlua.LuaDialog"
import "android.content.Context"

local M = {}
local utils = require("utils")
local radio_manager = require("radio_manager")

-- Variable local para mantener la lista filtrada en memoria mientras el diálogo está abierto
local listaActualRadios = {}

function M.MostrarGuardadas(filtro, ui_principal)
    -- 1. Cargar datos frescos desde el nuevo Manager (Storage V2)
    -- Esto trae los datos ya sean del JSON nuevo o migrados
    listaActualRadios = radio_manager.leerRadios()

    -- 2. Ordenar alfabéticamente
    table.sort(listaActualRadios, function(a, b) 
        -- Compatibilidad V2 (name) vs V1 (nombre)
        local nameA = (a.name or a.nombre or ""):lower()
        local nameB = (b.name or b.nombre or ""):lower()
        return nameA < nameB
    end)

    -- 3. Preparar los textos para el Adaptador (ListView)
    local radioInfoStrings = {}
    for _, radio in ipairs(listaActualRadios) do
        -- Lógica Híbrida: Busca 'name' (V2), si no hay, busca 'nombre' (V1), si no, usa default
        local rName = radio.name or radio.nombre or utils.getTranslation("sin_nombre")
        local rCountry = radio.country or radio.pais or utils.getTranslation("pais_desconocido")
        
        local info = string.format("%s - %s", rName, rCountry)
        table.insert(radioInfoStrings, info)
    end

    -- Crear adaptador
    local adapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, String(radioInfoStrings))

    -- 4. Definir Layout
    local layout = {
        LinearLayout,
        orientation = LinearLayout.VERTICAL,
        padding = "16dp",
        {
            TextView,
            text = utils.getTranslation("msj_guardada"), -- "Selecciona una radio..."
            textSize = "20sp",
            gravity = "center",
            paddingBottom = "16dp",
        },
        {
            LinearLayout,
            orientation = LinearLayout.HORIZONTAL,
            {
                EditText,
                id = "busquedaRadio",
                hint = utils.getTranslation("edicion_guardada"), -- "Buscar por nombre..."
                layout_width = "0dp",
                layout_height = "wrap_content",
                layout_weight = 1,
            },
            {
                Button,
                text = utils.getTranslation("buscar"),
                onClick = function()
                    -- Lógica de búsqueda local
                    local criterio = busquedaRadio.getText().toString():lower()
                    
                    -- Filtramos la listaActualRadios
                    local resultados = {}
                    local resultadosStrings = {}
                    
                    for _, radio in ipairs(listaActualRadios) do
                        local rName = (radio.name or radio.nombre or ""):lower()
                        local rCountry = (radio.country or radio.pais or ""):lower()
                        
                        if rName:find(criterio) or rCountry:find(criterio) then
                            table.insert(resultados, radio)
                            
                            -- Formatear texto para la lista
                            local displayData = string.format("%s - %s", 
                                radio.name or radio.nombre or utils.getTranslation("sin_nombre"), 
                                radio.country or radio.pais or utils.getTranslation("pais_desconocido"))
                            table.insert(resultadosStrings, displayData)
                        end
                    end
                    
                    -- Actualizar adaptador solo con los resultados
                    local newAdapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, String(resultadosStrings))
                    radioList.setAdapter(newAdapter)
                    
                    -- Guardar referencia temporal a los resultados para que el click coincida
                    -- (Un truco para no perder el índice correcto al hacer click)
                    radioList.setTag(resultados) 
                    
                    -- Ocultar teclado
                    local inputMethodManager = service.getSystemService(Context.INPUT_METHOD_SERVICE)
                    inputMethodManager.hideSoftInputFromWindow(busquedaRadio.getWindowToken(), 0)
                end,
                layout_width = "wrap_content",
            },
        },
        {
            GridView,
            id = "radioList",
            numColumns = 1, -- Mejor lista vertical para leer nombres largos
            layout_width = "fill",
            layout_height = "0dp",
            layout_weight = 1,
            adapter = adapter,
        },
        {
            LinearLayout,
            orientation = LinearLayout.HORIZONTAL,
            layout_width = "fill",
            layout_marginTop = "10dp",
            {
                Button,
                text = utils.getTranslation("showPlayer"),
                onClick = function()
                    radio_manager.MostrarReproductor()
                end,
                layout_width = "0dp",
                layout_weight = 1,
            },
            {
                Button,
                text = utils.getTranslation("volver"),
                onClick = function()
                    dlg.dismiss()
                    if ui_principal then ui_principal.mainMenu() end
                end,
                layout_width = "0dp",
                layout_weight = 1,
            },
        },
    }

    dlg = LuaDialog(service)
    dlg.View = loadlayout(layout)
    dlg.show()
    
    -- Inicializar Tag con la lista completa por defecto
    radioList.setTag(listaActualRadios)

    -- Evento Click
    radioList.onItemClick = function(l, v, position, id)
        -- Recuperar la lista correcta (puede ser la filtrada o la completa)
        local listaEnPantalla = radioList.getTag()
        local radio = listaEnPantalla[position + 1]
        
        if radio then
            -- Extraer datos con seguridad V1/V2
            local rName = radio.name or radio.nombre or "Radio"
            local rUrl = radio.url
            local rCountry = radio.country or radio.pais
            
            -- Menú de Opciones
            local opcDlg = LuaDialog(service)
            opcDlg.setTitle(string.format(utils.getTranslation("opc"), rName))
            
            local layoutOpc = {
                LinearLayout,
                orientation = LinearLayout.VERTICAL,
                padding="16dp",
                {
                    Button,
                    text = utils.getTranslation("play"),
                    onClick = function()
                        opcDlg.dismiss()
                        radio_manager.playRadio(rName, rUrl)
                    end,
                    layout_width = "fill",
                },
                {
                    Button,
                    text = utils.getTranslation("remover"),
                    onClick = function()
                        opcDlg.dismiss()
                        -- Confirmación antes de borrar
                        local confirm = LuaDialog(service)
                        confirm.setTitle(utils.getTranslation("remover"))
                        confirm.setMessage(string.format(utils.getTranslation("confirmar_eliminar") or "¿Eliminar %s?", rName))
                        confirm.setPositiveButton(utils.getTranslation("si") or "Sí", {
                            onClick = function()
                                -- Llamamos al manager pasando los datos necesarios para buscar el ID
                                local exito = radio_manager.EliminarRadio(rName, rUrl, rCountry)
                                if exito then
                                    -- Recargar la lista visualmente
                                    dlg.dismiss()
                                    M.MostrarGuardadas(filtro, ui_principal)
                                end
                            end
                        })
                        confirm.setNegativeButton(utils.getTranslation("no") or "No", nil)
                        confirm.show()
                    end,
                    layout_width = "fill",
                },
                {
                    Button,
                    text = utils.getTranslation("copiar"),
                    onClick = function()
                        service.copy(rUrl)
                        service.asyncSpeak(utils.getTranslation("ready"))
                        opcDlg.dismiss()
                    end,
                    layout_width = "fill",
                },
                {
                    Button,
                    text = utils.getTranslation("cancelar"), -- "Cerrar"
                    onClick = function()
                        opcDlg.dismiss()
                    end,
                    layout_width = "fill",
                }
            }
            opcDlg.setView(loadlayout(layoutOpc))
            opcDlg.show()
        end
    end
end

return M