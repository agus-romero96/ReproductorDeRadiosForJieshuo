local M = {}
local json = require("cjson")
local context = service.getContext()

-- Ruta del archivo de configuración (para guardar el idioma)
-- Usamos la misma lógica de carpetas segura
local configFilePath = "/storage/emulated/0/Documents/ReproductorRadios/config.json"

local translations = {
    ["es"] = {
        -- Menú Principal
        welcome = "Bienvenido al Reproductor de Radio Mundial",
        buscar = "Buscar",
        volver = "Volver",
        showPlayer = "Abrir Reproductor",
        exit = "Salir",
        idioma = "Idioma / Language",
        tit_idioma = "Selecciona un idioma",
        searchRadio = "Buscar en Internet (Radio-Browser)",
        savedRadios = "Mis Radios Guardadas",
        addRadio = "Agregar Manualmente",
        
        -- Mensajes de Estado
        noConnection = "Sin conexión a Internet.",
        ready = "¡Listo!",
        connecting = "Conectando con %s...",
        playing = "Reproduciendo: %s",
        paused = "Pausado",
        stopped = "Detenido",
        error_stream = "Error al reproducir. Intenta otra vez.",
        
        -- Acciones
        agregar = "Guardar",
        cancelar = "Cancelar",
        play = "Reproducir",
        remover = "Eliminar",
        copiar = "Copiar URL",
        guarda_favorito = "Añadir a Mis Radios",
        
        -- Diálogos y Confirmaciones
        confirmar_eliminar = "¿Estás seguro de borrar '%s'?",
        eliminada = "'%s' ha sido eliminada.",
        guardada_ok = "Radio guardada correctamente.",
        error_guardar = "Error al guardar. Verifica los datos.",
        ya_existe = "Esta radio ya está en tu lista.",
        url_invalida = "La URL no parece válida.",
        
        -- Reproductor v2.0
        timer_title = "Apagado Automático",
        timer_hint = "Minutos (ej: 15)",
        timer_set = "Apagado programado en %d minutos.",
        timer_off = "Radio apagada por temporizador.",
        mute_on = "Silenciado",
        mute_off = "Sonido activado",
        next = "Siguiente",
        prev = "Anterior",
        
        -- Búsqueda API
        titulo_api = "Buscador Global",
        search_prompt = "Escribe nombre, país o género...",
        searching = "Buscando...",
        results_found = "Encontradas %d radios.",
        no_results = "No se encontraron radios.",
        
        -- Textos genéricos
        sin_nombre = "Sin Nombre",
        pais_desconocido = "Mundo",
        si = "Sí",
        no = "No",
        -- módulo ui_agregar
        verificando = "Verificando URL...",
        opciones_url = "¿Qué deseas hacer con esta URL?",
        url_valida = "¡URL Válida!",
        error_datos = "Faltan datos (Nombre o País).",
    },
    ["en"] = {
        -- Main Menu
        welcome = "Welcome to World Radio Player",
        buscar = "Search",
        volver = "Back",
        showPlayer = "Open Player",
        exit = "Exit",
        idioma = "Language",
        tit_idioma = "Select Language",
        searchRadio = "Search Online (Radio-Browser)",
        savedRadios = "My Saved Radios",
        addRadio = "Add Manually",
        
        -- Status Messages
        noConnection = "No Internet connection.",
        ready = "Ready!",
        connecting = "Connecting to %s...",
        playing = "Playing: %s",
        paused = "Paused",
        stopped = "Stopped",
        error_stream = "Playback error. Try again.",
        
        -- Actions
        agregar = "Save",
        cancelar = "Cancel",
        play = "Play",
        remover = "Delete",
        copiar = "Copy URL",
        guarda_favorito = "Add to My Radios",
        
        -- Dialogs
        confirmar_eliminar = "Are you sure you want to delete '%s'?",
        eliminada = "'%s' deleted.",
        guardada_ok = "Radio saved successfully.",
        error_guardar = "Save error. Check data.",
        ya_existe = "This radio is already in your list.",
        url_invalida = "Invalid URL.",
        
        -- Player v2.0
        timer_title = "Sleep Timer",
        timer_hint = "Minutes (ex: 15)",
        timer_set = "Sleep timer set for %d minutes.",
        timer_off = "Radio stopped by timer.",
        mute_on = "Muted",
        mute_off = "Unmuted",
        next = "Next",
        prev = "Prev",
        
        -- API Search
        titulo_api = "Global Search",
        search_prompt = "Type name, country or tag...",
        searching = "Searching...",
        results_found = "Found %d radios.",
        no_results = "No radios found.",
        
        -- Generic
        sin_nombre = "Nameless",
        pais_desconocido = "World",
        si = "Yes",
        no = "No",
        -- ui_add module
        verificando = "Verifying URL...",
opciones_url = "What would you like to do?",
url_valida = "Valid URL!",
error_datos = "Missing data (Name or Country).",
    }
}

-- Configuración de Idioma
local lang = "es" -- Default

local function saveConfig()
    local data = { language = lang }
    local f = io.open(configFilePath, "w")
    if f then
        f:write(json.encode(data))
        f:close()
    end
end

local function loadConfig()
    local f = io.open(configFilePath, "r")
    if f then
        local content = f:read("*a")
        f:close()
        local ok, data = pcall(json.decode, content)
        if ok and data and data.language then
            lang = data.language
        end
    end
end

-- Inicializar al cargar
loadConfig()

function M.getTranslation(key)
    if translations[lang] and translations[lang][key] then
        return translations[lang][key]
    elseif translations["es"] and translations["es"][key] then
        return translations["es"][key] -- Fallback a español
    else
        return key -- Si no existe, devuelve la clave (para depurar)
    end
end

function M.setLanguage(newLang)
    if translations[newLang] then
        lang = newLang
        saveConfig()
    end
end

function M.getLanguage()
    return lang
end

-- Utilidad de Red
function M.VerifiConex()
    local cm = context.getSystemService(Context.CONNECTIVITY_SERVICE)
    local netInfo = cm.getActiveNetworkInfo()
    return netInfo ~= nil and netInfo.isConnected()
end

return M