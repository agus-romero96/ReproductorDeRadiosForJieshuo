require "import"
import "android.media.MediaPlayer"
import "android.media.AudioManager"
import "android.content.Context"
import "android.os.PowerManager"
import "android.net.wifi.WifiManager"

local M = {}
local service
local player = nil
local audioManager = nil
local wifiLock = nil
local focusListener = nil
local isInterrupted = false -- Para saber si fuimos pausados por una llamada

-- Inicializar servicios del sistema
function M.init(srv)
    service = srv
    audioManager = service.getSystemService(Context.AUDIO_SERVICE)
    
    -- Configurar WifiLock para mejorar streaming con pantalla apagada
    local wifiManager = service.getSystemService(Context.WIFI_SERVICE)
    if wifiManager then
        wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "JieshuoRadioLock")
        wifiLock.setReferenceCounted(false)
    end
end

-- Gestión de AudioFocus (Interrupciones por llamadas/YouTube)
local function getFocusListener()
    if not focusListener then
        focusListener = luajava.createProxy("android.media.AudioManager$OnAudioFocusChangeListener", {
            onAudioFocusChange = function(focusChange)
                if focusChange == AudioManager.AUDIOFOCUS_LOSS then
                    -- Pérdida total (otra app empezó a reproducir música)
                    M.stop()
                elseif focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT then
                    -- Pérdida temporal (llamada telefónica o notificación larga)
                    if M.isPlaying() then
                        M.pause()
                        isInterrupted = true -- Marcamos para reanudar luego
                    end
                elseif focusChange == AudioManager.AUDIOFOCUS_GAIN then
                    -- Recuperamos el foco (terminó la llamada)
                    if isInterrupted then
                        M.resume()
                        isInterrupted = false
                    else
                        -- Subir volumen si estaba bajo (ducking)
                        if player then player.setVolume(1.0, 1.0) end
                    end
                elseif focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK then
                    -- Bajar volumen (notificación corta)
                    if player then player.setVolume(0.1, 0.1) end
                end
            end
        })
    end
    return focusListener
end

local function requestFocus()
    local result = audioManager.requestAudioFocus(
        getFocusListener(),
        AudioManager.STREAM_MUSIC,
        AudioManager.AUDIOFOCUS_GAIN
    )
    return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
end

local function abandonFocus()
    if focusListener then
        audioManager.abandonAudioFocus(focusListener)
    end
end

-- ==================================================
-- MÉTODOS PÚBLICOS
-- ==================================================

function M.play(url, onPreparedCallback, onErrorCallback)
    -- 1. Detener anterior
    M.stop()

    -- 2. Pedir permiso al sistema de audio
    if not requestFocus() then
        service.asyncSpeak("Otras aplicaciones están usando el audio.")
        return
    end

    -- 3. Configurar Player
    player = MediaPlayer()
    
    -- WakeLock nativo del MediaPlayer (mantiene CPU despierta)
    player.setWakeMode(service, PowerManager.PARTIAL_WAKE_LOCK)
    
    -- Activar WifiLock
    if wifiLock then wifiLock.acquire() end

    player.setDataSource(url)
    player.setAudioStreamType(AudioManager.STREAM_MUSIC)
    
    -- Callbacks
    player.setOnPreparedListener({
        onPrepared = function(mp)
            mp.start()
            if onPreparedCallback then onPreparedCallback() end
        end
    })

    player.setOnErrorListener({
        onError = function(mp, what, extra)
            M.stop() -- Limpiar recursos
            if onErrorCallback then 
                onErrorCallback("Error de conexión (" .. what .. ")")
            else
                service.asyncSpeak("Error al reproducir stream.")
            end
            return true
        end
    })

    -- Iniciar carga asíncrona
    player.prepareAsync()
end

function M.stop()
    if player then
        pcall(function()
            if player.isPlaying() then player.stop() end
            player.release()
        end)
        player = nil
    end
    
    -- Liberar bloqueos
    if wifiLock and wifiLock.isHeld() then wifiLock.release() end
    abandonFocus()
    isInterrupted = false
end

function M.pause()
    if player and player.isPlaying() then
        player.pause()
    end
end

function M.resume()
    if player and not player.isPlaying() then
        player.start()
    end
end

function M.isPlaying()
    return player and player.isPlaying()
end

-- Control de volumen (Mute)
function M.setVolume(vol)
    if player then player.setVolume(vol, vol) end
end

return M