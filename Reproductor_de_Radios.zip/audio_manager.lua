require "import"
import "android.media.MediaPlayer"
import "android.media.AudioManager"
import "android.content.Context"
import "android.os.PowerManager"
import "android.net.wifi.WifiManager"
import "android.os.Handler"
import "android.net.Uri" -- NUEVO: Necesario para headers
import "java.util.HashMap" -- NUEVO: Para pasar el User-Agent

local M = {}
local service
local player = nil
local audioManager = nil
local wifiLock = nil
local focusListener = nil
local isInterrupted = false 

-- Variables para el control de tiempo
local timeoutHandler = Handler()
local timeoutRunnable = nil
local CONNECTION_TIMEOUT_MS = 60000 

-- Inicializar
function M.init(srv)
    service = srv
    audioManager = service.getSystemService(Context.AUDIO_SERVICE)
    
    local wifiManager = service.getSystemService(Context.WIFI_SERVICE)
    if wifiManager then
        wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "JieshuoRadioLock")
        wifiLock.setReferenceCounted(false)
    end
end

-- Audio Focus (Sin cambios)
local function getFocusListener()
    if not focusListener then
        focusListener = luajava.createProxy("android.media.AudioManager$OnAudioFocusChangeListener", {
            onAudioFocusChange = function(focusChange)
                if focusChange == AudioManager.AUDIOFOCUS_LOSS then
                    if M.isPlaying() then M.pause(); isInterrupted = true end
                elseif focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT then
                    if M.isPlaying() then M.pause(); isInterrupted = true end
                elseif focusChange == AudioManager.AUDIOFOCUS_GAIN then
                    if isInterrupted then M.resume(); isInterrupted = false else
                        if player then player.setVolume(1.0, 1.0) end
                    end
                elseif focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK then
                    if player then player.setVolume(0.1, 0.1) end
                end
            end
        })
    end
    return focusListener
end

local function requestFocus()
    local result = audioManager.requestAudioFocus(getFocusListener(), AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
    return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
end

local function abandonFocus()
    if focusListener then audioManager.abandonAudioFocus(focusListener) end
end

local function cancelTimeout()
    if timeoutRunnable then
        timeoutHandler.removeCallbacks(timeoutRunnable)
        timeoutRunnable = nil
    end
end

-- ==================================================
-- MÉTODOS PÚBLICOS
-- ==================================================

function M.play(url, onPreparedCallback, onErrorCallback)
    M.stop() 

    if not requestFocus() then
        service.asyncSpeak("Audio ocupado.")
        return
    end

    player = MediaPlayer()
    player.setWakeMode(service, PowerManager.PARTIAL_WAKE_LOCK)
    if wifiLock then wifiLock.acquire() end

    -- Timeout
    timeoutRunnable = luajava.createProxy("java.lang.Runnable", {
        run = function()
            if player and not player.isPlaying() then
                M.stop()
                local msg = "Tiempo agotado. El servidor no responde."
                if onErrorCallback then onErrorCallback(msg) else service.asyncSpeak(msg) end
            end
        end
    })
    timeoutHandler.postDelayed(timeoutRunnable, CONNECTION_TIMEOUT_MS)

    local status, err = pcall(function()
        player.setAudioStreamType(AudioManager.STREAM_MUSIC)
        
        -- 🔴 SOLUCIÓN MÁGICA AQUÍ 🔴
        -- Creamos headers para engañar al servidor
        local headers = HashMap()
        -- Usamos el User-Agent de VLC para que el servidor nos trate igual
        headers.put("User-Agent", "VLC/3.0.16 LibVLC/3.0.16")
        -- Alternativa si falla: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        
        -- Usamos la versión de setDataSource que acepta Contexto, Uri y Headers
        player.setDataSource(service, Uri.parse(url), headers)
        
        player.prepareAsync()
    end)

    if not status then
        cancelTimeout()
        if onErrorCallback then onErrorCallback("Error URL: " .. tostring(err)) end
        return
    end
    
    player.setOnPreparedListener({
        onPrepared = function(mp)
            cancelTimeout() 
            mp.start()
            if onPreparedCallback then onPreparedCallback() end
        end
    })

    player.setOnInfoListener({
        onInfo = function(mp, what, extra)
            if what == 701 then service.asyncSpeak("Buffering...") end
            return false
        end
    })

    player.setOnErrorListener({
        onError = function(mp, what, extra)
            cancelTimeout()
            M.stop() 
            local msg = "Error " .. what
            if what == -1004 then msg = "Error de Red (IO)" end
            if onErrorCallback then onErrorCallback(msg) end
            return true 
        end
    })
end

function M.stop()
    cancelTimeout()
    if player then
        pcall(function() if player.isPlaying() then player.stop() end; player.release() end)
        player = nil
    end
    if wifiLock and wifiLock.isHeld() then wifiLock.release() end
    abandonFocus()
    isInterrupted = false
end

function M.pause() if player and player.isPlaying() then player.pause() end end
function M.resume() if player and not player.isPlaying() then player.start() end end
function M.isPlaying() local s, r = pcall(function() return player and player.isPlaying() end); return s and r end
function M.setVolume(vol) if player then player.setVolume(vol, vol) end end

return M