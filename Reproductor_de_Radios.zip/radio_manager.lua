require "import"
import "android.media.MediaPlayer"
import "android.os.Handler"
import "android.content.Context"
import "android.widget.*"
import "com.androlua.LuaDialog"
import "android.graphics.Typeface" -- Importamos Typeface

local M = {}
local utils = require("utils")
local storage = require("storage") 
local audio_manager = require("audio_manager")

-- Inicialización
storage.init()
audio_manager.init(service)

-- Variables de estado para lógica de lista
local timerHandler = Handler()
local timerRunnable = nil

-- ==================================================
-- 1. GESTIÓN DE DATOS
-- ==================================================

function M.leerRadios()
    return storage.load()
end

function M.agregarRadio(nombre, url, pais)
    if url and nombre then
        if storage.addRadio(nombre, url, pais) then
            service.asyncSpeak(utils.getTranslation("guardada_ok"))
            return true
        end
    end
    service.asyncSpeak(utils.getTranslation("error_guardar"))
    return false
end

function M.EliminarRadio(nombre, url, pais)
    local radios = storage.load()
    for _, r in ipairs(radios) do
        -- Comparación laxa para encontrar la radio (Compatibilidad V1)
        if (r.name == nombre and r.url == url) or (r.nombre == nombre and r.url == url) then
            if storage.deleteRadio(r.id) then
                service.asyncSpeak(string.format(utils.getTranslation("eliminar") or "Eliminado", nombre))
                return true
            end
        end
    end
    service.asyncSpeak("No encontrada.")
    return false
end

-- ==================================================
-- 2. CONTROL DE AUDIO Y LISTA
-- ==================================================

function M.playRadio(name, url)
    _G.currentRadio = url
    _G.currentRadioName = name
    
    service.asyncSpeak(string.format(utils.getTranslation("connecting"), name))
    
    audio_manager.play(url, 
        function() -- OnPrepared
            _G.radioPlaying = true
            service.asyncSpeak(string.format(utils.getTranslation("playing"), name))
            -- Refrescamos la UI si está abierta
        end,
        function(err) -- OnError
            _G.radioPlaying = false
            service.asyncSpeak(utils.getTranslation("error_stream"))
        end
    )
end

function M.stopRadio()
    audio_manager.stop()
    _G.radioPlaying = false
    _G.currentRadio = nil
    
    if timerRunnable then
        timerHandler.removeCallbacks(timerRunnable)
        timerRunnable = nil
    end
    service.asyncSpeak(utils.getTranslation("stopped"))
end

local function cambiarRadio(direccion)
    local lista = storage.load()
    if #lista == 0 then service.asyncSpeak("Lista vacía"); return end
    
    local index = 1
    for i, r in ipairs(lista) do
        if r.url == _G.currentRadio then
            index = i
            break
        end
    end
    
    index = index + direccion
    if index > #lista then index = 1 end
    if index < 1 then index = #lista end
    
    local r = lista[index]
    local name = r.name or r.nombre or "Radio"
    M.playRadio(name, r.url)
end

function M.SiguienteRadio() cambiarRadio(1) end
function M.AnteriorRadio() cambiarRadio(-1) end

-- ==================================================
-- 3. TEMPORIZADOR
-- ==================================================

function M.configurarTemporizador()
    local input = EditText(service)
    input.setInputType(2) -- Solo números
    input.setHint(utils.getTranslation("timer_hint"))
    
    local dlg = LuaDialog(service)
    dlg.setTitle(utils.getTranslation("timer_title"))
    dlg.setView(input)
    dlg.setPositiveButton(utils.getTranslation("si"), function()
        local min = tonumber(input.getText().toString())
        if min and min > 0 then
            if timerRunnable then timerHandler.removeCallbacks(timerRunnable) end
            
            timerRunnable = luajava.createProxy("java.lang.Runnable", {
                run = function()
                    M.stopRadio()
                    service.asyncSpeak(utils.getTranslation("timer_off"))
                    timerRunnable = nil
                end
            })
            
            timerHandler.postDelayed(timerRunnable, min * 60 * 1000)
            service.asyncSpeak(string.format(utils.getTranslation("timer_set"), min))
        end
    end)
    dlg.setNegativeButton(utils.getTranslation("cancelar"), nil)
    dlg.show()
end

-- ==================================================
-- 4. INTERFAZ REPRODUCTOR
-- ==================================================

function M.MostrarReproductor()
    local nombre = _G.currentRadioName or utils.getTranslation("sin_nombre")
    local estado = audio_manager.isPlaying() and utils.getTranslation("playing"):format("") or utils.getTranslation("paused")
    
    local layout = {
        LinearLayout,
        orientation="vertical",
        padding="16dp",
        gravity="center",
        -- Título (Quitamos textStyle="bold" y usamos id para setearlo después)
        { TextView, id="tvTitulo", text=nombre, textSize="22sp", gravity="center", paddingBottom="10dp" },
        { TextView, text=estado, textSize="14sp", textColor="#AAAAAA", gravity="center", paddingBottom="20dp" },
        
        -- Controles
        {
            LinearLayout, orientation="horizontal", layout_width="fill", gravity="center",
            { Button, text=utils.getTranslation("prev"), onClick=function() M.AnteriorRadio() end, layout_width="60dp" },
            { 
                Button, 
                text=audio_manager.isPlaying() and utils.getTranslation("paused") or utils.getTranslation("play"), 
                onClick=function() 
                    if audio_manager.isPlaying() then 
                        audio_manager.pause() 
                        service.asyncSpeak(utils.getTranslation("paused"))
                    else 
                        if _G.currentRadio then 
                            audio_manager.resume() 
                            if not audio_manager.isPlaying() then M.playRadio(nombre, _G.currentRadio) end
                        else
                            service.asyncSpeak("Error")
                        end
                    end 
                end, 
                layout_width="120dp" 
            },
            { Button, text=utils.getTranslation("next"), onClick=function() M.SiguienteRadio() end, layout_width="60dp" },
        },
        
        -- Herramientas
        {
            LinearLayout, orientation="horizontal", layout_width="fill", layout_marginTop="15dp",
            { Button, text="⏱", onClick=function() M.configurarTemporizador() end, layout_weight=1 },
            { Button, text="🔇", onClick=function(v) M.silence(v) end, layout_weight=1 },
            { Button, text="❌", onClick=function() return true end, layout_weight=1 },
        }
    }

    local dlg = LuaDialog(service)
    dlg.setView(loadlayout(layout))
    
    -- Aplicar negrita manualmente para evitar error de loadlayout
    tvTitulo.setTypeface(Typeface.DEFAULT_BOLD)
    
    dlg.setNegativeButton("Ocultar", nil) 
    dlg.setPositiveButton("Stop", function() M.stopRadio() end)
    dlg.show()
end

function M.silence(btnView)
    if _G.isMuted then
        audio_manager.setVolume(1.0)
        _G.isMuted = false
        service.asyncSpeak(utils.getTranslation("mute_off"))
    else
        audio_manager.setVolume(0.0)
        _G.isMuted = true
        service.asyncSpeak(utils.getTranslation("mute_on"))
    end
end

return M