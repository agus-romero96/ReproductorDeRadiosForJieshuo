require "import"
import "java.io.File"
import "android.os.Environment"

local M = {}
local json = require("cjson")

-- 1. Definir rutas seguras (Estrategia Gemini)
-- Usamos Documents para persistencia real ante desinstalaciones
local externalDir = Environment.getExternalStorageDirectory().toString()
local BASE_DIR = externalDir .. "/Documents/ReproductorRadios"
local DB_FILE = BASE_DIR .. "/library.json"

-- Rutas antiguas para migración (basado en main.lua v1.0)
local LEGACY_PATHS = {
    externalDir .. "/解说/Plugins/Reproductor de Radios/datos.txt",
    externalDir .. "/解说/Complementos/Reproductor de Radios/datos.txt"
}

-- Estructura de datos por defecto
local default_db = {
    version = "2.0",
    radios = {} -- Array de objetos
}

-- Helper: Leer archivo completo
local function readFile(path)
    local f = io.open(path, "r")
    if f then
        local content = f:read("*a")
        f:close()
        return content
    end
    return nil
end

-- Helper: Guardar archivo
local function saveFile(path, content)
    local f = io.open(path, "w")
    if f then
        f:write(content)
        f:close()
        return true
    end
    return false
end

-- 2. Inicialización y Migración
function M.init()
    local dir = File(BASE_DIR)
    if not dir.exists() then
        dir.mkdirs()
    end

    -- Verificar si ya existe la nueva DB
    if not File(DB_FILE).exists() then
        -- Si no existe, intentamos migrar de la v1.0
        local migratedRadios = M.tryMigrateLegacy()
        
        if #migratedRadios > 0 then
            -- Guardamos lo recuperado
            M.save(migratedRadios)
            service.asyncSpeak("Base de datos actualizada a versión 2.0")
        else
            -- Si no hay nada antiguo, creamos DB limpia
            M.save({})
        end
    end
end

-- Lógica crítica: Rescatar datos del formato viejo (datos.txt)
function M.tryMigrateLegacy()
    local recovered = {}
    local foundPath = nil

    for _, path in ipairs(LEGACY_PATHS) do
        if File(path).exists() then
            foundPath = path
            break
        end
    end

    if foundPath then
        local f = io.open(foundPath, "r")
        if f then
            for line in f:lines() do
                -- Parseo del formato viejo: {"nombre":"X", "url":"Y", "pais":"Z"}
                local nombre, url, pais = line:match('{"nombre":"(.-)", "url":"(.-)", "pais":"(.-)"}')
                if nombre and url then
                    table.insert(recovered, {
                        id = os.time() .. math.random(100, 999), -- Generar ID único v2.0
                        name = nombre,
                        url = url,
                        country = pais or "Desconocido",
                        added_at = os.time()
                    })
                end
            end
            f:close()
            -- Opcional: Renombrar el archivo viejo a .bak para no re-importar
            File(foundPath).renameTo(File(foundPath .. ".bak"))
        end
    end
    return recovered
end

-- 3. Métodos Públicos de Acceso (API)

-- Cargar todas las radios
function M.load()
    local content = readFile(DB_FILE)
    if content then
        local status, data = pcall(json.decode, content)
        if status and data and data.radios then
            return data.radios
        end
    end
    return {}
end

-- Guardar lista completa de radios
function M.save(radiosList)
    local data = {
        version = "2.0",
        updated_at = os.time(),
        radios = radiosList
    }
    return saveFile(DB_FILE, json.encode(data))
end

-- Añadir una radio nueva
function M.addRadio(name, url, country)
    local radios = M.load()
    table.insert(radios, {
        id = os.time() .. math.random(100, 999), -- ID único para evitar problemas de nombres duplicados
        name = name,
        url = url,
        country = country or "Desconocido",
        added_at = os.time()
    })
    return M.save(radios)
end

-- Eliminar radio por ID (mucho más seguro que por nombre)
function M.deleteRadio(radioId)
    local radios = M.load()
    local newRadios = {}
    for _, r in ipairs(radios) do
        if r.id ~= radioId then
            table.insert(newRadios, r)
        end
    end
    return M.save(newRadios)
end

return M