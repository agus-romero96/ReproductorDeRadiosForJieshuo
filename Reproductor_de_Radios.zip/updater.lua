require "import"
import "java.io.File"
import "java.io.FileOutputStream"
import "java.io.FileInputStream"
import "java.util.zip.ZipInputStream"
import "com.androlua.Http"
import "android.app.AlertDialog"

local M = {}
local json = require("cjson")
local service, context, basePath

-- 🔴🔴 IMPORTANTE: CAMBIA ESTA URL POR LA DE TU REPOSITORIO DE RADIOS 🔴🔴
-- Debe apuntar al archivo raw 'version.json' de tu nuevo repo
local VERSION_URL = "https://raw.githubusercontent.com/agus-romero96/Reproductor_Radios_Jieshuo/main/version.json"

function M.init(srv, ctx, path)
    service = srv
    context = ctx
    basePath = path
end

-- Función auxiliar: Descomprimir ZIP (Java puro)
local function unzip(zipFile, targetDir)
    local buffer = byte[1024]
    local zis = ZipInputStream(FileInputStream(zipFile))
    local entry = zis.getNextEntry()
    while entry do
        local fileName = entry.getName()
        local newFile = File(targetDir, fileName)
        if entry.isDirectory() then
            newFile.mkdirs()
        else
            -- Asegurar que la carpeta padre existe
            local parent = newFile.getParentFile()
            if not parent.exists() then parent.mkdirs() end
            
            local fos = FileOutputStream(newFile)
            local len = zis.read(buffer)
            while len > 0 do
                fos.write(buffer, 0, len)
                len = zis.read(buffer)
            end
            fos.close()
        end
        entry = zis.getNextEntry()
    end
    zis.closeEntry()
    zis.close()
end

-- Descargar e instalar actualización
local function startUpdate(zipUrl)
    service.asyncSpeak("Descargando actualización del Reproductor...")
    local downloadPath = basePath .. "/update_temp.zip"
    
    Http.download(zipUrl, downloadPath, function(result)
        if result and File(downloadPath).exists() then
            service.asyncSpeak("Instalando...")
            
            -- Hacemos la descompresión en un hilo aparte para no congelar
            task(50, function()
                local success, err = pcall(function()
                    unzip(downloadPath, basePath)
                    File(downloadPath).delete()
                end)
                
                if success then
                    service.asyncSpeak("¡Actualizado! Reiniciando plugin...")
                    -- Opcional: Recargar la interfaz si es necesario
                else
                    service.asyncSpeak("Error al instalar: " .. tostring(err))
                end
            end)
        else
            service.asyncSpeak("Error en la descarga. Verifica tu conexión.")
        end
    end)
end

-- Función pública: Comprobar versión
function M.check(currentVersion)
    -- Petición silenciosa en segundo plano
    Http.get(VERSION_URL, function(code, body)
        if code == 200 and body then
            local status, data = pcall(json.decode, body)
            if status and data then
                local remoteVersion = tonumber(data.version)
                local localVersion = tonumber(currentVersion)
                
                -- Solo mostramos alerta si hay versión nueva
                if remoteVersion and remoteVersion > localVersion then
                    service.asyncSpeak("Nueva versión del Reproductor disponible")
                    
                    local builder = AlertDialog.Builder(context)
                    builder.setTitle("Actualización v" .. remoteVersion)
                    builder.setMessage("Novedades:\n" .. (data.changelog or "Mejoras de rendimiento") .. "\n\n¿Quieres actualizar ahora?")
                    
                    builder.setPositiveButton("Sí, actualizar", {
                        onClick = function()
                            startUpdate(data.url)
                        end
                    })
                    
                    builder.setNegativeButton("Ahora no", nil)
                    builder.show()
                end
            end
        end
    end)
end

return M